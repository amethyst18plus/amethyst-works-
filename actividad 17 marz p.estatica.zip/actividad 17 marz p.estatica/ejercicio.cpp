#include<iostream>
using namespace std;

class jarr{
	
public: 

float*orden(float arr[],int t){
	
	float aux;
	
	static float arrx[100];
	for (int i=0;i<t;i++){
		arrx[i]=arr[i];
		} 
	for (int i=0;i<t;i++){
		for (int j=0;j<t-1;j++){
			if(arrx[j]>arrx[j+1]){
				aux=arrx[j];
				arrx[j]=arrx[j+1];
				arrx[j+1]=aux;
				}
			}
		}
		return arrx;
	}
	
	};

int main (){
	float suma=0;
	int t;
	float num;
	float *apuntador;
	
	cout<<"\n ingrese el tamaño del arreglo \n";
	cin>>t;
	
	float arreglo[t];
	
	cout<<"\n ingrese los valores del arreglo \n";
	
	apuntador=arreglo;
	
	for (int i=0;i<t;i++){
		cin>>num;
		arreglo[i]=num;
		suma=suma+num;
		}
	float promedio;
	promedio=suma/t;
	cout<<"\n el promedio es: "<<promedio;	
		
	jarr miarreglo;
	
	float menor,mayor;
	
		menor=*(miarreglo.orden(apuntador,t));
		mayor=*(miarreglo.orden(apuntador,t)+t-1);
	cout<<"\n el menor valor es: "<<menor;
	cout<<"\n el mayor valor es: "<<mayor;
	
	
	
	return 0;
	}
